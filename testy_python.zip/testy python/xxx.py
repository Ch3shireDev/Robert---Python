﻿from turtle import *
from math import *

#funkcja testuj() do testowania rozwiązania
def testuj(n):
    # zadanie 2 - obliczenowe
    if n==2:
        dane = [ [1 ,8] , [10 ,4]]
        wyniki = [7, 123]
        for i in range(len(dane)):
            if n == 2: x = ile(dane[i][0],dane[i][1])
            if x == wyniki[i]:
                print('wykonuję test dla zadania',n,': ', dane[i], ' wynik:', x, 'dobrze')
            else:
                print('wykonuję test dla zadania',n,': ', dane[i], ' wynik:', x, 'źle')
        return           
    #zadania 1 i 3 - graficzne
    a=499
    b=796
    reset()
    tracer(0)
    if n==1:
        motyw()
    if n==3:
        statek(3)
        
    pu(); home(); pd()
    pu();fd(b/2);pd()
    lt(90)
    color("red")
    for i in range(2):
        fd(a//2);lt(90)
        fd(b);lt(90)
        fd(a//2)
    rt(90)
    pu();bk(b/2);pd()
    color("black")
    update()

    tracer(1)
    if n==1:
        addshape("zad1.gif")
    if n==3:
        addshape("zad3.gif")
      
    zolw_test = Turtle()
    if n==1:
        zolw_test.shape("zad1.gif")
    if n==3:
        zolw_test.shape("zad3.gif")
    
    zolw_test.speed(0)
    zolw_test.pu()
    zolw_test.ondrag(zolw_test.goto)


#tutaj jest miejsce na Twoje rozwiązania zadania

